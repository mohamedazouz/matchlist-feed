alter table mytable add column data2 text;
