
PYTHONPATH=../../python:$PYTHONPATH
PATH=../../python:../../scripts:$PATH
export PYTHONPATH PATH

#. /opt/pgsql/env

