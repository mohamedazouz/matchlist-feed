
--*-- Local-Table: mydata

alter table @mydata@ add column data2 text;

