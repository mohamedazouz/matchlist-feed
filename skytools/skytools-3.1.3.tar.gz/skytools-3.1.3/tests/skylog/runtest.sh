#! /bin/sh

. ../env.sh

exec ./logtest.py test.ini "$@"

