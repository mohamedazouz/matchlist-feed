
\set ECHO none
\i ../pgq/pgq.sql
\i structure/tables.sql
\i structure/functions.sql

