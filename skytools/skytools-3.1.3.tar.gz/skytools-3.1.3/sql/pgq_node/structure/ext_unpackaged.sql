
ALTER EXTENSION pgq_node ADD SCHEMA pgq_node;

ALTER EXTENSION pgq_node ADD TABLE pgq_node.node_location;
ALTER EXTENSION pgq_node ADD TABLE pgq_node.node_info;
ALTER EXTENSION pgq_node ADD TABLE pgq_node.local_state;
ALTER EXTENSION pgq_node ADD TABLE pgq_node.subscriber_info;

