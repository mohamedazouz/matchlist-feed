
grant usage on schema pgq_node to public;

