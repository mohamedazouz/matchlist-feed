\i structure/functions.sql
