
-- tag data objects as dumpable

SELECT pg_catalog.pg_extension_config_dump('pgq_node.node_location', '');
SELECT pg_catalog.pg_extension_config_dump('pgq_node.node_info', '');
SELECT pg_catalog.pg_extension_config_dump('pgq_node.local_state', '');
SELECT pg_catalog.pg_extension_config_dump('pgq_node.subscriber_info', '');


