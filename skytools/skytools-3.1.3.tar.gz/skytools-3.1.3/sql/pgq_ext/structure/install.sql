\i structure/tables.sql
\i structure/upgrade.sql
\i structure/grants.sql

