
ALTER EXTENSION pgq_ext ADD SCHEMA pgq_ext;

ALTER EXTENSION pgq_ext ADD TABLE pgq_ext.completed_tick;
ALTER EXTENSION pgq_ext ADD TABLE pgq_ext.completed_batch;
ALTER EXTENSION pgq_ext ADD TABLE pgq_ext.completed_event;
ALTER EXTENSION pgq_ext ADD TABLE pgq_ext.partial_batch;

