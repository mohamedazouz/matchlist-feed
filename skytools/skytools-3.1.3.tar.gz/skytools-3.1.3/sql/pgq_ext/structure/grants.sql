
grant usage on schema pgq_ext to public;

