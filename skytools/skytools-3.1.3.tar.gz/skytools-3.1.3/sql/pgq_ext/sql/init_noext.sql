\set ECHO off
\i structure/install.sql

