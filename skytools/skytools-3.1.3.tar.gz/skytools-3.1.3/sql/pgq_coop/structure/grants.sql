
GRANT usage ON SCHEMA pgq_coop TO public;

