\i structure/schema.sql
\i structure/functions.sql
\i structure/grants.sql
