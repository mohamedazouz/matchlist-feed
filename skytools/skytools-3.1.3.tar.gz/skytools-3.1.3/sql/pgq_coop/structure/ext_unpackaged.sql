
ALTER EXTENSION pgq_coop ADD SCHEMA pgq_coop;

