
\set ECHO none
\i ../pgq/pgq.sql
\i structure/schema.sql
\i structure/functions.sql
\set ECHO all

