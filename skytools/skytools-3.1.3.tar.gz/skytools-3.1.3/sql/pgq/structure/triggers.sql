
-- Section: Public Triggers

-- Group: Trigger Functions

-- \i triggers/pgq.logutriga.sql
\i triggers/pgq_triggers.sql

