\i structure/func_internal.sql
\i structure/func_public.sql
\i structure/triggers.sql
