
-- brute-force uninstall
drop schema pgq cascade;

