
\set ECHO none
\set VERBOSITY 'terse'
set client_min_messages = 'warning';
-- \i ../txid/txid.sql
-- \i pgq.sql
\i structure/install.sql

\set ECHO all

