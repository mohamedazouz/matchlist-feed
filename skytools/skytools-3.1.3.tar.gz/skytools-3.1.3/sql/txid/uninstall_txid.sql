
DROP DOMAIN txid;
DROP TYPE txid_snapshot cascade;
DROP SCHEMA txid CASCADE;
DROP FUNCTION txid_current();


