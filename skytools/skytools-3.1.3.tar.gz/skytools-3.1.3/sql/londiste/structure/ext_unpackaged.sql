ALTER EXTENSION londiste ADD SCHEMA londiste;

ALTER EXTENSION londiste ADD TABLE londiste.table_info;
ALTER EXTENSION londiste ADD TABLE londiste.seq_info;
ALTER EXTENSION londiste ADD TABLE londiste.applied_execute;
ALTER EXTENSION londiste ADD TABLE londiste.pending_fkeys;

