\i structure/tables.sql
\i structure/functions.sql
\i structure/triggers.sql
\i structure/grants.sql
