
-- tag data objects as dumpable

SELECT pg_catalog.pg_extension_config_dump('londiste.table_info', '');
SELECT pg_catalog.pg_extension_config_dump('londiste.seq_info', '');
SELECT pg_catalog.pg_extension_config_dump('londiste.applied_execute', '');
SELECT pg_catalog.pg_extension_config_dump('londiste.pending_fkeys', '');


